package com.example.CollegeNotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeNotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
